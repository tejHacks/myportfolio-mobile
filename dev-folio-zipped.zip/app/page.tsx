"use client"

import { useState, useEffect } from "react"
import { AnimatePresence } from "framer-motion"

import { StatusBar } from "@/components/status-bar"
import { NavigationDock } from "@/components/navigation-dock"
import { CommandPalette } from "@/components/command-palette"
import { ScrollToTop } from "@/components/scroll-to-top"
import { ScreenWrapper } from "@/components/screen-wrapper"

import { HeroScreen } from "@/components/screens/hero-screen"
import { AboutScreen } from "@/components/screens/about-screen"
import { SkillsScreen } from "@/components/screens/skills-screen"
import { ExperienceScreen } from "@/components/screens/experience-screen"
import { ProjectsScreen } from "@/components/screens/projects-screen"
import { WritingScreen } from "@/components/screens/writing-screen"
import { ContactScreen } from "@/components/screens/contact-screen"

type Screen = "home" | "about" | "skills" | "experience" | "projects" | "writing" | "contact"

export default function Portfolio() {
  const [activeScreen, setActiveScreen] = useState<Screen>("home")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleNavigate = (screen: string) => {
    setActiveScreen(screen as Screen)
    // Scroll to top when navigating
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const renderScreen = () => {
    switch (activeScreen) {
      case "home":
        return <HeroScreen onNavigate={handleNavigate} />
      case "about":
        return <AboutScreen />
      case "skills":
        return <SkillsScreen />
      case "experience":
        return <ExperienceScreen />
      case "projects":
        return <ProjectsScreen />
      case "writing":
        return <WritingScreen />
      case "contact":
        return <ContactScreen />
      default:
        return <HeroScreen onNavigate={handleNavigate} />
    }
  }

  if (!mounted) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <main className="relative min-h-screen bg-black text-white overflow-x-hidden" suppressHydrationWarning>


      {/* Status bar */}
      <StatusBar />

      {/* Command palette */}
      <CommandPalette onNavigate={handleNavigate} />

      {/* Main content */}
      <AnimatePresence mode="wait">
        <ScreenWrapper key={activeScreen} screenKey={activeScreen}>
          {renderScreen()}
        </ScreenWrapper>
      </AnimatePresence>

      {/* Navigation dock */}
      <NavigationDock activeScreen={activeScreen} onNavigate={handleNavigate} />

      {/* Scroll to top */}
      <ScrollToTop />


    </main>
  )
}
