import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
})

export const metadata: Metadata = {
  title: 'Olateju Olamide Emmanuel | Mobile Developer & ML Engineer',
  description: 'Building beautiful, performant mobile experiences with React Native. 3+ years creating web and mobile applications. Passionate about machine learning, Linux, open-source, and technical writing.',
  generator: 'v0.app',
  keywords: ['Mobile Developer', 'React Native', 'ML Engineer', 'Technical Writer', 'Full Stack Developer'],
  authors: [{ name: 'Olateju Olamide Emmanuel' }],
  icons: {
    icon: [
      {
        url: '/profile-photo.jpeg',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/profile-photo.jpeg',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/profile-photo.jpeg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#000000',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} bg-black`}>
      <body className="font-sans antialiased bg-black text-white overflow-x-hidden">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
