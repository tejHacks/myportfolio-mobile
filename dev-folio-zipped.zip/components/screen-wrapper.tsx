"use client"

import { motion, AnimatePresence } from "framer-motion"
import { ReactNode } from "react"

interface ScreenWrapperProps {
  children: ReactNode
  screenKey: string
}

const variants = {
  initial: {
    opacity: 0,
    scale: 0.98,
    y: 20,
  },
  enter: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: [0.25, 0.1, 0.25, 1],
    },
  },
  exit: {
    opacity: 0,
    scale: 0.98,
    y: -20,
    transition: {
      duration: 0.3,
      ease: [0.25, 0.1, 0.25, 1],
    },
  },
}

export function ScreenWrapper({ children, screenKey }: ScreenWrapperProps) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={screenKey}
        initial="initial"
        animate="enter"
        exit="exit"
        variants={variants}
        className="min-h-screen pt-7 pb-24"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  )
}
