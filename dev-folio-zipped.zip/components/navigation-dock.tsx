"use client"

import { motion } from "framer-motion"
import {
  Home,
  User,
  Layers,
  Briefcase,
  FolderKanban,
  BookOpen,
  Mail,
} from "lucide-react"

interface NavigationDockProps {
  activeScreen: string
  onNavigate: (screen: string) => void
}

const navItems = [
  { id: "home", icon: Home, label: "Home" },
  { id: "about", icon: User, label: "About" },
  { id: "skills", icon: Layers, label: "Skills" },
  { id: "experience", icon: Briefcase, label: "Experience" },
  { id: "projects", icon: FolderKanban, label: "Projects" },
  { id: "writing", icon: BookOpen, label: "Writing" },
  { id: "contact", icon: Mail, label: "Contact" },
]

export function NavigationDock({ activeScreen, onNavigate }: NavigationDockProps) {
  return (
    <motion.nav
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50"
    >
      <div className="glass-strong rounded-2xl px-2 py-2 flex items-center gap-1">
        {navItems.map((item) => {
          const isActive = activeScreen === item.id
          const Icon = item.icon
          
          return (
            <motion.button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`relative p-3 rounded-xl transition-colors ${
                isActive
                  ? "text-white"
                  : "text-white/50 hover:text-white/80"
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-white/10 rounded-xl"
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              )}
              <Icon className="w-5 h-5 relative z-10" />
              <span className="sr-only">{item.label}</span>
            </motion.button>
          )
        })}
      </div>
      
      {/* Home indicator bar */}
      <div className="flex justify-center mt-2">
        <div className="w-32 h-1 bg-white/20 rounded-full" />
      </div>
    </motion.nav>
  )
}
