"use client"

import { motion } from "framer-motion"
import { Building2, Calendar, MapPin, FileText, GraduationCap } from "lucide-react"

const experiences = [
  {
    company: "MamaCare (Startup)",
    role: "Frontend & Mobile Developer",
    period: "Mar 2025 – Present",
    location: "Remote",
    description: "Building a comprehensive pregnancy and postpartum companion web app using React Native, Expo, Firebase, and TypeScript. Shipped features including fetal development tracking, BMI calculator, health reminders, and weekly tips.",
    tags: ["React Native", "Expo", "Firebase", "TypeScript"],
    current: true,
  },
  {
    company: "Kairos Initiative",
    role: "Mobile Developer",
    period: "Mar 2025 – Jan 2026",
    location: "Remote",
    description: "Led mobile development of Kairos, a cross-platform prayer reminder app. Implemented scheduled push notifications tied to prayer hours, background task handling, offline-first architecture, and integrated Bible verse feeds.",
    tags: ["React Native", "Expo", "TypeScript", "Push Notifications"],
    current: true,
  },
  {
    company: "HNG Internship",
    role: "Mobile Developer Intern",
    period: "Oct 2025 – Dec 2025",
    location: "Remote",
    description: "Built and shipped multiple apps including a Bible quiz game, crypto wallet prototype, and wallpaper app. Worked within cross-functional remote teams practicing agile delivery, code reviews, and collaborative Git workflows.",
    tags: ["React Native", "Agile", "Git", "Team Collaboration"],
    current: false,
  },
  {
    company: "Exodox",
    role: "Frontend & Mobile Developer",
    period: "Jun 2024 – Feb 2025",
    location: "Remote",
    description: "Developed and maintained web and mobile interfaces across multiple product features using React and React Native. Collaborated on component design systems, performance optimization, and cross-platform delivery pipelines.",
    tags: ["React Native", "React", "Design Systems"],
    current: false,
  },
  {
    company: "Midas-Tech Training Institute",
    role: "Programming Instructor & Lead Frontend Mentor",
    period: "Jun 2024 – Oct 2024",
    location: "Nigeria",
    description: "Taught frontend and backend development (React, Laravel, JavaScript) and secure coding practices to 20+ students. Mentored students on building real projects with component-based and mobile-first thinking.",
    tags: ["Teaching", "React", "Laravel", "JavaScript"],
    current: false,
  },
  {
    company: "ATC Africa",
    role: "Community Lead (Remote)",
    period: "Feb 2024 – Dec 2024",
    location: "Remote",
    description: "Led tech events, code-along sessions, and open-source workshops for 50+ beginner developers. Organized developer mentorship programs and community building initiatives.",
    tags: ["Community", "Leadership", "Open Source", "Mentorship"],
    current: false,
  },
  {
    company: "Ntech Systems",
    role: "Junior Web Developer Trainer (Intern)",
    period: "Jun 2023 – Oct 2023",
    location: "Nigeria",
    description: "Mentored junior developers on HTML, CSS, JavaScript best practices and Git workflows. Improved project outcomes by ~5% through code review and training sessions.",
    tags: ["HTML", "CSS", "JavaScript", "Git", "Training"],
    current: false,
  },
]

const education = {
  school: "Achievers University, Owo, Nigeria",
  degree: "B.Sc. Computer Science",
  period: "2021 – 2025",
  achievements: [
    "President, Computer Science Department",
    "SRC Lead",
    "Class Representative",
    "Lead & Mentor at ATC Africa"
  ],
  coursework: ["Software Engineering", "Data Structures & Algorithms", "AI", "OOP", "Cybersecurity", "HCI"]
}

export function ExperienceScreen() {
  return (
    <div className="min-h-screen px-4 md:px-6 pt-8 md:pt-12 pb-24 overflow-y-auto hide-scrollbar">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Experience</h1>
          <p className="text-lg text-white/50">My professional journey and career timeline</p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-white/10 transform md:-translate-x-1/2" />

          {/* Experience items */}
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <motion.div
                key={`${exp.company}-${exp.period}`}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`relative flex flex-col md:flex-row gap-8 ${
                  index % 2 === 0 ? "md:flex-row-reverse" : ""
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-1/2 w-4 h-4 transform -translate-x-1/2 z-10">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.1 + 0.2 }}
                    className={`w-4 h-4 rounded-full border-2 ${
                      exp.current
                        ? "bg-green-400 border-green-400"
                        : "bg-black border-white/50"
                    }`}
                  />
                  {exp.current && (
                    <motion.div
                      animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute inset-0 rounded-full bg-green-400"
                    />
                  )}
                </div>

                {/* Content */}
                <div className={`flex-1 pl-8 md:pl-0 ${index % 2 === 0 ? "md:pr-12" : "md:pl-12"}`}>
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="glass rounded-2xl p-6 glow-hover transition-all"
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Building2 className="w-4 h-4 text-white/50" />
                          <h3 className="text-lg font-semibold text-white">{exp.company}</h3>
                          {exp.current && (
                            <span className="px-2 py-0.5 text-xs bg-green-400/20 text-green-400 rounded-full">
                              Current
                            </span>
                          )}
                        </div>
                        <p className="text-white/70">{exp.role}</p>
                      </div>
                    </div>

                    {/* Meta info */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-white/50 mb-4">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{exp.period}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{exp.location}</span>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-sm text-white/60 leading-relaxed mb-4">
                      {exp.description}
                    </p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-2">
                      {exp.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 text-xs text-white/70 bg-white/5 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                </div>

                {/* Empty space for opposite side */}
                <div className="hidden md:block flex-1" />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Education Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-16"
        >
          <h2 className="text-2xl font-semibold text-white mb-6 text-center flex items-center justify-center gap-2">
            <GraduationCap className="w-6 h-6" />
            Education
          </h2>
          <div className="glass rounded-2xl p-6">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-4">
              <div>
                <h3 className="text-lg font-semibold text-white">{education.degree}</h3>
                <p className="text-white/70">{education.school}</p>
              </div>
              <span className="text-sm text-white/50 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {education.period}
              </span>
            </div>
            
            <div className="mb-4">
              <p className="text-sm text-white/50 mb-2">Leadership & Activities:</p>
              <div className="flex flex-wrap gap-2">
                {education.achievements.map((achievement) => (
                  <span
                    key={achievement}
                    className="px-3 py-1 text-xs text-white/70 bg-white/10 rounded-full"
                  >
                    {achievement}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <p className="text-sm text-white/50 mb-2">Coursework:</p>
              <div className="flex flex-wrap gap-2">
                {education.coursework.map((course) => (
                  <span
                    key={course}
                    className="px-3 py-1 text-xs text-white/60 bg-white/5 rounded-full"
                  >
                    {course}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Download Resume */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mt-12 text-center"
        >
          <a
            href="/resume.pdf"
            download="Olateju_Olamide_Resume.pdf"
            className="inline-flex items-center gap-2 glass px-6 py-3 rounded-full hover:bg-white/10 transition-all"
          >
            <FileText className="w-5 h-5 text-white/70" />
            <span className="text-white font-medium">Download Full Resume</span>
          </a>
        </motion.div>
      </div>
    </div>
  )
}
