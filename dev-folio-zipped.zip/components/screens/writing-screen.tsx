"use client"

import { motion } from "framer-motion"
import { Clock, ArrowUpRight, BookOpen, TrendingUp, Heart } from "lucide-react"

interface Article {
  id: string
  title: string
  excerpt: string
  readTime: string
  date: string
  category: string
  claps?: number
  featured?: boolean
  url: string
}

const articles: Article[] = [
  {
    id: "1",
    title: "Machine Learning: An Introduction to the Basics (Without the Hype)",
    excerpt: "Machine Learning has a reputation problem. Let me break it down without the buzzwords.",
    readTime: "8 min read",
    date: "Feb 2026",
    category: "ML/AI",
    claps: 30,
    featured: true,
    url: "https://medium.com/@olateju202/machine-learning-an-introduction-to-the-basics-without-the-hype-3a3d19c4310e",
  },
  {
    id: "2",
    title: "Node.js: Protecting your Backend like a Pro",
    excerpt: "In software development, your backend is like your home — and Node.js gives you the keys. But a strong door without a lock invites trouble.",
    readTime: "10 min read",
    date: "Oct 2025",
    category: "Backend",
    claps: 24,
    featured: true,
    url: "https://medium.com/@olateju202/node-js-protecting-your-backend-like-a-pro-ce702304c842",
  },
  {
    id: "3",
    title: "10 Lessons from a Computer Science Student in a Private Nigerian University",
    excerpt: "I signed out of school on Friday, June 27th, 2025 — same day I wrote my final paper. After years of navigating the private school maze...",
    readTime: "12 min read",
    date: "Jun 2025",
    category: "Personal",
    claps: 89,
    featured: true,
    url: "https://medium.com/@olateju202/10-lessons-from-a-computer-science-student-in-a-private-nigerian-university-ed756457c671",
  },
  {
    id: "4",
    title: "How to Start JavaScript and Solidify Your Learning Process",
    excerpt: "Starting with JavaScript and solidifying your learning process involves a combination of theoretical understanding, practical application...",
    readTime: "7 min read",
    date: "Nov 2023",
    category: "JavaScript",
    claps: 3,
    url: "https://medium.com/@olateju202/how-to-start-javascript-and-solidify-your-learning-process-1c042692b287",
  },
  {
    id: "5",
    title: "React Native vs Flutter in 2026: What Actually Matters for Startups",
    excerpt: "A practical comparison for startup founders and developers choosing their mobile stack.",
    readTime: "9 min read",
    date: "Apr 2026",
    category: "Mobile",
    url: "https://medium.com/@olateju202/react-native-vs-flutter-in-2026-what-actually-matters-for-startups-1f3635cb308b",
  },
  {
    id: "6",
    title: "Linux vs Windows for Developers: I Switched — Here's the Truth",
    excerpt: "I got tired of fighting my development environment more than my actual code. So I switched.",
    readTime: "8 min read",
    date: "Apr 2026",
    category: "Linux",
    url: "https://medium.com/@olateju202/linux-vs-windows-for-developers-i-switched-heres-the-truth-7bce96b91581",
  },
  {
    id: "7",
    title: "25 Christian Software & Faith Based Tech Apps we Can Build in 2026",
    excerpt: "Technology is one of the most powerful tools for spreading ideas across the world. In the past, the printing press helped distribute the...",
    readTime: "15 min read",
    date: "Mar 2026",
    category: "Faith Tech",
    claps: 2,
    url: "https://medium.com/@olateju202/25-christian-software-fath-based-tech-apps-we-can-build-in-2026-for-the-kingdom-of-god-812e5367ff97",
  },
  {
    id: "8",
    title: "25 C++ Project Ideas for Developers",
    excerpt: "From console games to high-performance tools — build these to boost your portfolio, master modern C++, and stand out in interviews.",
    readTime: "12 min read",
    date: "Feb 2026",
    category: "C++",
    claps: 3,
    url: "https://medium.com/stackademic/25-c-project-ideas-for-developers-601743920236",
  },
  {
    id: "9",
    title: "C++: The Language Of The Millennium",
    excerpt: "Some languages arrive quietly and solve a problem. Others arrive loudly, burn bright, and fade.",
    readTime: "10 min read",
    date: "Feb 2026",
    category: "C++",
    claps: 20,
    url: "https://medium.com/@olateju202/c-the-language-of-the-millenium-16e8635615ec",
  },
  {
    id: "10",
    title: "Overplanning, Comparison, and Emotional Hoarding: What Being A Developer's Actually Like",
    excerpt: "Software development isn't hard because of code.",
    readTime: "6 min read",
    date: "Feb 2026",
    category: "Personal",
    claps: 2,
    url: "https://medium.com/@olateju202/overplanning-comparison-and-emotional-hoarding-what-being-a-developer-s-actually-like-543d696be7cb",
  },
  {
    id: "11",
    title: "Speaker Diarization: Teaching Machines Who Spoke When",
    excerpt: "Speech recognition learned how to hear. Speaker diarization learned how to pay attention.",
    readTime: "8 min read",
    date: "Feb 2026",
    category: "ML/AI",
    claps: 4,
    url: "https://medium.com/@olateju202/speaker-diarization-teaching-machines-who-spoke-when-b3ea70cf9dcd",
  },
  {
    id: "12",
    title: "PHP: The Right Tool, at the Right Time",
    excerpt: "There's a strange ritual in the tech industry: we declare tools dead long before checking whether they're still doing their jobs.",
    readTime: "7 min read",
    date: "Feb 2026",
    category: "Backend",
    claps: 1,
    url: "https://medium.com/stackademic/php-the-right-tool-at-the-right-time-c7f1519ab585",
  },
]

export function WritingScreen() {
  const featuredArticles = articles.filter((a) => a.featured)
  const regularArticles = articles.filter((a) => !a.featured)
  const totalClaps = articles.reduce((sum, a) => sum + (a.claps || 0), 0)

  return (
    <div className="min-h-screen px-4 md:px-6 pt-8 md:pt-12 pb-24 overflow-y-auto hide-scrollbar">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Writing</h1>
          <p className="text-lg text-white/50">Thoughts, tutorials, and technical articles</p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-4 mb-12"
        >
          <div className="glass rounded-2xl p-4 text-center">
            <BookOpen className="w-5 h-5 mx-auto mb-2 text-white/50" />
            <div className="text-2xl font-bold text-white">{articles.length}+</div>
            <div className="text-xs text-white/50">Articles</div>
          </div>
          <div className="glass rounded-2xl p-4 text-center">
            <Heart className="w-5 h-5 mx-auto mb-2 text-white/50" />
            <div className="text-2xl font-bold text-white">{totalClaps}+</div>
            <div className="text-xs text-white/50">Claps</div>
          </div>
          <div className="glass rounded-2xl p-4 text-center">
            <TrendingUp className="w-5 h-5 mx-auto mb-2 text-white/50" />
            <div className="text-2xl font-bold text-white">10K+</div>
            <div className="text-xs text-white/50">Total Reads</div>
          </div>
        </motion.div>

        {/* Featured articles */}
        {featuredArticles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-12"
          >
            <h2 className="text-xl font-semibold text-white mb-6">Featured</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {featuredArticles.slice(0, 4).map((article, index) => (
                <motion.a
                  key={article.id}
                  href={article.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -4 }}
                  className="group glass rounded-2xl p-6 glow-hover transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <span className="px-3 py-1 text-xs font-medium bg-white/10 text-white/70 rounded-full">
                      {article.category}
                    </span>
                    <ArrowUpRight className="w-5 h-5 text-white/30 group-hover:text-white group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                  </div>

                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-glow transition-all line-clamp-2">
                    {article.title}
                  </h3>
                  
                  <p className="text-sm text-white/50 mb-4 line-clamp-2">
                    {article.excerpt}
                  </p>

                  <div className="flex items-center justify-between text-xs text-white/40">
                    <div className="flex items-center gap-3">
                      <span>{article.date}</span>
                      <span className="w-1 h-1 rounded-full bg-white/40" />
                      <span>{article.readTime}</span>
                    </div>
                    {article.claps && (
                      <div className="flex items-center gap-1">
                        <Heart className="w-3 h-3" />
                        <span>{article.claps}</span>
                      </div>
                    )}
                  </div>
                </motion.a>
              ))}
            </div>
          </motion.div>
        )}

        {/* All articles */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-xl font-semibold text-white mb-6">All Articles</h2>
          <div className="space-y-4">
            {regularArticles.map((article, index) => (
              <motion.a
                key={article.id}
                href={article.url}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.05 }}
                whileHover={{ x: 8 }}
                className="group flex items-start gap-4 glass rounded-xl p-4 glow-hover transition-all"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-white/50">{article.category}</span>
                    <span className="w-1 h-1 rounded-full bg-white/30" />
                    <span className="text-xs text-white/40">{article.date}</span>
                  </div>
                  
                  <h3 className="font-medium text-white group-hover:underline underline-offset-4 decoration-white/30 transition-all line-clamp-1">
                    {article.title}
                  </h3>
                  
                  <p className="text-sm text-white/50 mt-1 line-clamp-1">
                    {article.excerpt}
                  </p>
                </div>

                <div className="flex items-center gap-3 text-xs text-white/40 shrink-0">
                  {article.claps && (
                    <div className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      <span>{article.claps}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{article.readTime}</span>
                  </div>
                </div>
              </motion.a>
            ))}
          </div>
        </motion.div>

        {/* View more on Medium */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-12 text-center"
        >
          <a
            href="https://medium.com/@olateju202"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 glass rounded-full text-white hover:bg-white/10 transition-colors"
          >
            <span>See more articles on Medium</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </motion.div>
      </div>
    </div>
  )
}
