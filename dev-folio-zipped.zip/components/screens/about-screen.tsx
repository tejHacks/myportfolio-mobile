"use client";

import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Code2, Smartphone, Brain, Terminal, Camera, Plus } from "lucide-react";

function AnimatedCounter({
  end,
  duration = 2,
  suffix = "",
}: {
  end: number;
  duration?: number;
  suffix?: string;
}) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView) return;

    let startTime: number;
    let animationFrame: number;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / (duration * 1000), 1);

      setCount(Math.floor(progress * end));

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration, isInView]);

  return (
    <span ref={ref}>
      {count}
      {suffix}
    </span>
  );
}

const stats = [
  { label: "Years Experience", value: 4, suffix: "+" },
  { label: "Projects Shipped", value: 17, suffix: "+" },
  { label: "Technologies", value: 28, suffix: "+" },
  { label: "Articles Written", value: 12, suffix: "+" },
];

const highlights = [
  {
    icon: Smartphone,
    title: "React Native Specialist",
    description:
      "Building cross-platform mobile apps with Expo, TypeScript, and native performance.",
  },
  {
    icon: Brain,
    title: "ML/AI Engineer",
    description:
      "Implementing on-device ML solutions using TensorFlow Lite, PyTorch, and computer vision.",
  },
  {
    icon: Code2,
    title: "Full-Stack Developer",
    description:
      "Creating end-to-end solutions with Node.js, Laravel, FastAPI, and modern databases.",
  },
  {
    icon: Terminal,
    title: "Linux Enthusiast",
    description:
      "Passionate about open-source, Docker, CLI tools, and system administration.",
  },
];

export function AboutScreen() {
  return (
    <div className="min-h-screen px-4 md:px-6 pt-8 md:pt-12 pb-24 overflow-y-auto hide-scrollbar">
      <div className="max-w-4xl mx-auto">
        {/* Header with Photo */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          {/* Profile Photo Placeholder */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
            className="relative w-32 h-32 mx-auto mb-6"
          >
            {/* Photo container - replace src with actual photo */}
            <div className="w-full h-full rounded-full glass border-2 border-white/20 overflow-hidden flex items-center justify-center group cursor-pointer">
              <img
                src="/profile-photo.jpeg"
                alt="Olateju Olamide Emmanuel"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Status indicator */}
            <div className="absolute bottom-1 right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-black" />
          </motion.div>

          <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-4">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-sm text-white/70">Available for work</span>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Olateju Olamide Emmanuel
          </h1>
          <p className="text-base md:text-lg text-white/50 mb-2">
            Mobile Developer & Global Lead (Mobile App) @ CSMTech
          </p>
          <p className="text-sm text-white/40">Ibadan, Nigeria</p>
        </motion.div>

        {/* Bio section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass rounded-3xl p-8 mb-12"
        >
          <h2 className="text-2xl font-semibold text-white mb-4">About Me</h2>
          <div className="space-y-4 text-white/70 leading-relaxed text-sm md:text-base">
            <p>
              Graduated Computer Science graduate (2025) with 4+ years of
              hands-on experience building cross-platform mobile apps at the
              intersection of faith, robotics, and health. Currently serving as
              Global Lead for Mobile App Development at CSMTech, where I lead
              mobile initiatives and mentor developers.
            </p>
            <p>
              I specialize in React Native & Expo, TypeScript, on-device ML
              (TensorFlow Lite), and backend integration (Node.js, Python,
              FastAPI). My passion lies in creating performant, accessible apps
              that solve real problems—from prayer apps to healthcare solutions
              to Linux command learning tools.
            </p>
            <p>
              Based in Ibadan, I&apos;m also a prolific technical writer on
              Medium with 12+ published articles covering React Native, ML/AI,
              Linux, and developer journey. I&apos;m an open-source advocate,
              Linux enthusiast, and firm believer in building technology that
              positively impacts communities.
            </p>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className="glass rounded-2xl p-6 text-center glow-hover transition-shadow"
            >
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">
                <AnimatedCounter end={stat.value} suffix={stat.suffix} />
              </div>
              <div className="text-sm text-white/50">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        {/* Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <h2 className="text-2xl font-semibold text-white mb-6 text-center">
            What I Do
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {highlights.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  className="glass rounded-2xl p-6 glow-hover transition-all cursor-default"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-xl bg-white/5">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {item.title}
                      </h3>
                      <p className="text-sm text-white/50 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Languages */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <p className="text-sm text-white/40">
            Languages: English (Fluent) | Yoruba (Native) | Spanish & French
            (Basic)
          </p>
        </motion.div>
      </div>
    </div>
  );
}
