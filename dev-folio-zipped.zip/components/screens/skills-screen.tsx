"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Smartphone, Globe, Server, Wrench } from "lucide-react"

type SkillCategory = "mobile" | "web" | "devops" | "tools"

const categories = [
  { id: "mobile" as SkillCategory, label: "Mobile", icon: Smartphone },
  { id: "web" as SkillCategory, label: "Web", icon: Globe },
  { id: "devops" as SkillCategory, label: "DevOps", icon: Server },
  { id: "tools" as SkillCategory, label: "Tools", icon: Wrench },
]

const skills: Record<SkillCategory, string[]> = {
  mobile: [
    "React Native",
    "Expo",
    "NativeWind",
    "Android Studio",
    "Kotlin",
    "iOS Development",
    "Mobile UI/UX",
    "App Performance",
  ],
  web: [
    "React",
    "Next.js",
    "TypeScript",
    "JavaScript",
    "Node.js",
    "TailwindCSS",
    "HTML/CSS",
    "Laravel",
      "PHP"
  ],
  devops: [
    "Linux",
    "Docker",
    "CI/CD",
    "AWS",
    "Nginx",
    "Bash",
    "Shell Scripting",
    "npm",
  ],
  tools: [
    "Git",
    "VS Code",
    "Android Studio",
    "Postman",
    "Figma",
    "Firebase",
    "Python",
    "SQLite",
  ],
}

function SkillTag({ name, index }: { name: string; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.03, type: "spring", stiffness: 300 }}
      whileHover={{ scale: 1.05, y: -2 }}
      className="px-4 py-2.5 glass rounded-xl text-sm font-medium text-white/90 hover:text-white hover:bg-white/10 transition-all cursor-default"
    >
      {name}
    </motion.div>
  )
}

export function SkillsScreen() {
  
  const [activeCategory, setActiveCategory] = useState<SkillCategory>("mobile")

  return (
    <div className="min-h-screen px-4 md:px-6 pt-8 md:pt-12 pb-24 overflow-y-auto hide-scrollbar">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Skills</h1>
          <p className="text-lg text-white/50">Technologies and tools I work with</p>
        </motion.div>

        {/* Category toggles */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex justify-center mb-12"
        >
          <div className="glass rounded-2xl p-1.5 flex gap-1">
            {categories.map((category) => {
              const Icon = category.icon
              const isActive = activeCategory === category.id
              return (
                <motion.button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`relative px-4 py-3 rounded-xl flex items-center gap-2 transition-colors ${
                    isActive ? "text-black" : "text-white/60 hover:text-white/90"
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeSkillCategory"
                      className="absolute inset-0 bg-white rounded-xl"
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  )}
                  <Icon className="w-4 h-4 relative z-10" />
                  <span className="text-sm font-medium relative z-10 hidden sm:inline">
                    {category.label}
                  </span>
                </motion.button>
              )
            })}
          </div>
        </motion.div>

        {/* Skills display */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {/* Skills card */}
            <div className="glass rounded-3xl p-6 md:p-8">
              <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
                {(() => {
                  const Icon = categories.find(c => c.id === activeCategory)?.icon || Smartphone
                  return <Icon className="w-5 h-5" />
                })()}
                {categories.find(c => c.id === activeCategory)?.label} Skills
              </h3>

              {/* Skills tags grid */}
              <div className="flex flex-wrap gap-3">
                {skills[activeCategory].map((skill, index) => (
                  <SkillTag key={skill} name={skill} index={index} />
                ))}
              </div>
            </div>

            {/* All skills summary */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-8 glass rounded-3xl p-6 md:p-8"
            >
              <h3 className="text-lg font-semibold text-white mb-6">All Technologies</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {categories.map((category) => {
                  const Icon = category.icon
                  return (
                    <motion.button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className={`p-4 rounded-2xl transition-all ${
                        activeCategory === category.id
                          ? "bg-white/10 border border-white/20"
                          : "bg-white/5 border border-transparent hover:bg-white/10"
                      }`}
                    >
                      <Icon className="w-6 h-6 mx-auto mb-2 text-white/70" />
                      <div className="text-sm font-medium text-white">{category.label}</div>
                      <div className="text-xs text-white/50 mt-1">
                        {skills[category.id].length} skills
                      </div>
                    </motion.button>
                  )
                })}
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}
