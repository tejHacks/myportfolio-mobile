"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ExternalLink,
  Github,
  X,
  Download,
  Apple,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

interface ProjectDownload {
  available: boolean;
  url?: string;
}

interface Project {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  tags: string[];
  icon: string;
  color: string;
  screenshots: string[];
  downloads: {
    apk: ProjectDownload;
    ios: ProjectDownload;
  };
  links?: {
    github?: string;
    live?: string;
    playStore?: string;
  };
}

const projects: Project[] = [
  {
    id: "kairos",
    name: "Kairos",
    description:
      "A modern prayer companion that helps Christians build consistent prayer habits through reminders, Scripture meditation, and guided fasting.",
    longDescription:
      "Kairos is a thoughtfully designed prayer companion built to help Christians cultivate a consistent and meaningful prayer life. Stay connected to God with personalized prayer reminders, Scripture meditation, guided fasting plans, and a peaceful, distraction-free experience. Whether you're praying at home, at work, or on the go, Kairos keeps your daily spiritual disciplines within reach with offline Scripture access, customizable prayer schedules, gentle notifications, and a built-in meditation timer. Designed with simplicity and intention, Kairos empowers believers to develop lasting habits of prayer, reflection, and spiritual growth every day.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "SQLite",
      "Push Notifications",
      "AsyncStorage",
      "Prayer Timer",
    ],
    icon: "/projects/kairos/icon.png",
    color: "#3B82F6",
    screenshots: [
      "/projects/kairos/landnig-home.png",
      "/projects/kairos/kairos-meditate.png",
      "/projects/kairos/kairos-pray.png",
      "/projects/kairos/kairos-fast.png",
      "/projects/kairos/kairos-scribe.png",
    ],
    downloads: {
      apk: { available: true },
      ios: { available: false },
    },
    links: {
      github: "https://github.com/tejHacks/kairos-mobile-app",
      playStore: "https://play.google.com/store/apps/details?id=com.kairos",
    },
  },
  {
    id: "scribe",
    name: "Scribe",
    description: "Note-taking with Bible, Strong's dictionary, and quizzes",
    longDescription:
      "Powerful note-taking app for Christians combining study tools with sermon capture. Features offline KJV Bible, Strong's Exhaustive Concordance for word-by-word analysis,  interactive Bible quizzes, fast full-text search, and clipboard export for notes and study materials.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "SQLite",
      "Expo AV",
      "Bible API",
      "Quiz Engine",
      "Full-text Search",
    ],
    icon: "/projects/scribe/logo.png",
    color: "#10B981",
    screenshots: [
      "/projects/scribe/screenshot-1.png",
      "/projects/scribe/screenshot-2.png",
      "/projects/scribe/screenshot-3.png",
      "/projects/scribe/screenshot-5.png",
      "/projects/scribe/quiz.png",
    ],
    downloads: { apk: { available: false }, ios: { available: false } },
    links: {
      github: "https://github.com",
      playStore: "https://play.google.com/store/apps/details?id=com.scribe",
    },
  },
  {
    id: "jaundx",
    name: "JaundX",
    description: "AI-powered neonatal jaundice detection with instant alerts",
    longDescription:
      "Healthcare-focused mobile app for early detection and monitoring of neonatal jaundice using on-device AI. The TensorFlow Lite model predicts bilirubin levels instantly, provides color-coded risk alerts, tracks trends over time, and generates doctor referral recommendations.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "TensorFlow Lite",
      "Camera API",
      "On-device ML",
      "Healthcare",
    ],
    icon: "/projects/lumicare/icon.png",
    color: "#F59E0B",
    screenshots: [
      "/projects/jaundx/screenshot-1.png",
      "/projects/jaundx/screenshot-2.png",
      "/projects/jaundx/screenshot-3.png",
      "/projects/jaundx/screenshot-4.png",
    ],
    downloads: { apk: { available: false }, ios: { available: false } },
    links: {
      github: "https://github.com",
      playStore: "https://play.google.com/store/apps/details?id=com.jaundx",
    },
  },
  {
    id: "smoothspeex",
    name: "SmoothSpeex",
    description: "Meeting recorder with AI speaker diarization and transcripts",
    longDescription:
      "Intelligent audio recording app with on-device speaker diarization. Automatically identifies and separates different speakers, generates labeled transcripts, timestamps every segment, highlights key quotes, and exports to multiple formats.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "Expo AV",
      "Speaker Diarization",
      "Audio Processing",
      "Transcription",
    ],
    icon: "/projects/smoothspeex/icon.png",
    color: "#8B5CF6",
    screenshots: [
      "/projects/smoothspeex/screenshot-1.png",
      "/projects/smoothspeex/screenshot-2.png",
      "/projects/smoothspeex/screenshot-3.png",
      "/projects/smoothspeex/screenshot-4.png",
    ],
    downloads: { apk: { available: false }, ios: { available: false } },
    links: {
      github: "https://github.com",
      playStore:
        "https://play.google.com/store/apps/details?id=com.smoothspeex",
    },
  },
  {
    id: "faithquotes",
    name: "FaithQuotes",
    description: "Daily devotional quotes with reminders and sharing",
    longDescription:
      "A beautifully designed devotional quotes app delivering daily inspirational wisdom from Kenneth E. Hagin and Christian thought leaders. Features 100+ hand-curated quotes, daily reminders, elegant gold typography, swipe navigation, and one-tap sharing to WhatsApp.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "Push Notifications",
      "React Native SVG",
      "Expo Font",
    ],
    icon: "/projects/faithquotes/icon.png",
    color: "#EC4899",
    screenshots: [
      "/projects/faithquotes/faithquotes-2.png",
      "/projects/faithquotes/faithquotes-3.png",
      "/projects/faithquotes/faithquotes-5.png",
      "/projects/faithquotes/image.png",
    ],
    downloads: {
      apk: {
        available: true,
        url: "https://github.com/tejHacks/christian-quotes-mobile-app/releases/download/v1.0.0/BibleQuotes.apk",
      },
      ios: { available: false },
    },
    links: {
      github: "https://github.com/tejHacks/christian-quotes-mobile-app",
      playStore:
        "https://play.google.com/store/apps/details?id=com.faithquotes",
    },
  },
  {
    id: "hagah",
    name: "Hagah",
    description: "Daily scripture declarations with text-to-speech meditation",
    longDescription:
      "A transformative daily declaration app rooted in Joshua 1:8. Scripture-backed declarations voiced back to you 5x via TTS for deep meditation, ambient background sounds, war room for fighting fear, lust, doubt and strongholds with KJV battle scriptures, pins for saving favourite declarations, and custom push notification scheduling.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "Text-to-Speech",
      "Expo AV",
      "Push Notifications",
      "AsyncStorage",
    ],
    icon: "/projects/hagah/logo.png",
    color: "#c9923a",
    screenshots: [
      "/projects/hagah/screen-1.png",
      "/projects/hagah/screen-2.png",
      "/projects/hagah/screen-3.png",
      "/projects/hagah/screen-4.png",
      "/projects/hagah/screen-5.png",
    ],
    downloads: {
      apk: {
        available: true,
        url: "https://play.google.com/store/apps/details?id=com.olateju.hagahapp",
      },
      ios: { available: false },
    },
    links: {
      github: "https://github.com",
      playStore:
        "https://play.google.com/store/apps/details?id=com.olateju.hagahapp",
    },
  },
  {
    id: "terminalmaster",
    name: "TerminalMaster",
    description:
      "Linux mastery with 200+ commands, quizzes, and daily challenges",
    longDescription:
      "Comprehensive Linux command learning platform with 200+ commands across all categories. Features detailed command reference, daily challenges, interactive quizzes, spaced repetition system, progress tracking with achievements, offline access, and gamification elements.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "SQLite",
      "Quiz Engine",
      "Gamification",
      "Spaced Repetition",
    ],
    icon: "/projects/terminalmaster/icon.png",
    color: "#EC4899",
    screenshots: [
      "/projects/terminalmaster/screenshot-1.png",
      "/projects/terminalmaster/screenshot-2.png",
      "/projects/terminalmaster/screenshot-3.png",
      "/projects/terminalmaster/screenshot-4.png",
      "/projects/terminalmaster/screenshot-5.png",
      "/projects/terminalmaster/screenshot-6.png",
    ],
    downloads: { apk: { available: false }, ios: { available: false } },
    links: {
      github: "https://github.com",
      playStore:
        "https://play.google.com/store/apps/details?id=com.terminalmaster",
    },
  },
  {
    id: "yorubaverse",
    name: "YorùbáVerse",
    description:
      "Tonal Yorùbá learning app with native-speaker audio and dialogue mode",
    longDescription:
      "A tone-first Yorùbá learning app built for heritage speakers and beginners alike. Unlike apps that ignore diacritics, YorùbáVerse treats tone as a core feature — every word is tagged with its high/mid/low tone sequence and voiced by native speakers. Features a two-speaker dialogue mode for conversational practice, offline-downloadable audio packs, spaced-repetition review tuned for tonal recall, and gamified tone-matching quizzes.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "SQLite",
      "FTS5",
      "Expo AV",
      "Spaced Repetition",
      "Offline-first",
    ],
    icon: "/projects/yorubaverse/icon.png",
    color: "#059669",
    screenshots: [
      "/projects/yorubaverse/screenshot-1.png",
      "/projects/yorubaverse/screenshot-2.png",
      "/projects/yorubaverse/screenshot-3.png",
      "/projects/yorubaverse/screenshot-4.png",
    ],
    downloads: { apk: { available: false }, ios: { available: false } },
    links: {
      github: "https://github.com",
      playStore:
        "https://play.google.com/store/apps/details?id=com.yorubaverse",
    },
  },
  {
    id: "splitit",
    name: "SplitIt!!",
    description:
      "Group foodstuff bulk-buying and cost-sharing, split down to the naira",
    longDescription:
      "A fintech micro-billing app built for inflation-impacted markets, letting groups bulk-buy foodstuff and split the cost fairly. Create a basket, add payers by name or SplitIt ID, and the Split Engine instantly computes each person's share plus a 1.5% convenience fee. Generates a dynamic QR code and short text code (e.g. SP-9281) for instant lookup, with WhatsApp/email dispatch and Paystack-powered temporary virtual accounts for settlement.",
    tags: [
      "React Native",
      "Expo",
      "TypeScript",
      "Node.js",
      "Express",
      "Paystack",
      "QR Codes",
      "Fintech",
    ],
    icon: "/projects/splitit/icon.png",
    color: "#0F7A45",
    screenshots: [
      "/projects/splitit/screenshot-1.png",
      "/projects/splitit/screenshot-2.png",
      "/projects/splitit/screenshot-3.png",
      "/projects/splitit/screenshot-4.png",
    ],
    downloads: { apk: { available: false }, ios: { available: false } },
    links: {
      github: "https://github.com",
    },
  },
];

// ── App icon card ─────────────────────────────────────────────────────────────
function AppIcon({
  icon,
  color,
  name,
}: {
  icon: string;
  color: string;
  name: string;
}) {
  const [err, setErr] = useState(false);
  return (
    <div
      className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg overflow-hidden flex-shrink-0"
      style={{
        background: `linear-gradient(135deg, ${color} 0%, ${color}CC 100%)`,
        boxShadow: `0 6px 24px ${color}40`,
      }}
    >
      {!err ? (
        <img
          src={icon}
          alt={name}
          className="w-full h-full object-cover"
          onError={() => setErr(true)}
        />
      ) : (
        <span className="text-2xl font-bold text-white">{name.charAt(0)}</span>
      )}
    </div>
  );
}

// ── Screenshot gallery — no phone frame, raw image, bigger ───────────────────
function ScreenshotGallery({
  screenshots,
  color,
  name,
}: {
  screenshots: string[];
  color: string;
  name: string;
}) {
  const [idx, setIdx] = useState(0);
  const [errors, setErrors] = useState<Record<number, boolean>>({});

  const prev = () =>
    setIdx((i) => (i - 1 + screenshots.length) % screenshots.length);
  const next = () => setIdx((i) => (i + 1) % screenshots.length);
  const onErr = (i: number) => setErrors((e) => ({ ...e, [i]: true }));

  return (
    <div className="relative select-none">
      {/* Image container — no phone chrome, just the screenshot */}
      <div
        className="relative w-full mx-auto overflow-hidden rounded-2xl"
        style={{ maxWidth: 300 }}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.22 }}
          >
            {!errors[idx] ? (
              <img
                src={screenshots[idx]}
                alt={`${name} screenshot ${idx + 1}`}
                className="w-full h-auto object-contain rounded-2xl"
                style={{ maxHeight: 520 }}
                onError={() => onErr(idx)}
              />
            ) : (
              <div
                className="w-full flex flex-col items-center justify-center gap-3 rounded-2xl"
                style={{ height: 400, background: `${color}14` }}
              >
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center"
                  style={{ background: `${color}28` }}
                >
                  <span className="text-2xl font-bold" style={{ color }}>
                    {name.charAt(0)}
                  </span>
                </div>
                <p className="text-xs text-white/30">Screenshot {idx + 1}</p>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Prev / Next — only if more than 1 */}
      {screenshots.length > 1 && (
        <div className="flex items-center justify-center gap-4 mt-4">
          <button
            onClick={prev}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 transition-colors"
            aria-label="Previous"
          >
            <ChevronLeft className="w-5 h-5 text-white" />
          </button>

          {/* Dots */}
          <div className="flex gap-1.5 items-center">
            {screenshots.map((_, i) => (
              <button
                key={i}
                onClick={() => setIdx(i)}
                className={`rounded-full transition-all ${i === idx ? "w-5 h-2 bg-white" : "w-2 h-2 bg-white/30 hover:bg-white/50"}`}
                aria-label={`Screenshot ${i + 1}`}
              />
            ))}
          </div>

          <button
            onClick={next}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 transition-colors"
            aria-label="Next"
          >
            <ChevronRight className="w-5 h-5 text-white" />
          </button>
        </div>
      )}
    </div>
  );
}

function DownloadButton({
  type,
  download,
  color,
}: {
  type: "apk" | "ios";
  download: ProjectDownload;
  color: string;
}) {
  const isApk = type === "apk";
  const Icon = isApk ? Download : Apple;
  const label = isApk ? "Download APK" : "App Store";

  if (!download.available) {
    return (
      <div className="flex items-center gap-3 px-5 py-3 rounded-xl bg-white/5 border border-white/10 opacity-50 cursor-not-allowed">
        <Icon className="w-5 h-5 text-white/40" />
        <div className="text-left">
          <p className="text-sm font-medium text-white/40">{label}</p>
          <p className="text-xs text-white/30">Coming Soon</p>
        </div>
      </div>
    );
  }

  return (
    <a
      href={download.url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-3 px-5 py-3 rounded-xl transition-all hover:scale-105 active:scale-95"
      style={{
        background: `linear-gradient(135deg, ${color} 0%, ${color}CC 100%)`,
        boxShadow: `0 4px 20px ${color}40`,
      }}
    >
      <Icon className="w-5 h-5 text-white" />
      <div className="text-left">
        <p className="text-sm font-medium text-white">{label}</p>
        <p className="text-xs text-white/70">Available Now</p>
      </div>
    </a>
  );
}

// ── Modal ─────────────────────────────────────────────────────────────────────
function ProjectModal({
  project,
  onClose,
}: {
  project: Project;
  onClose: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] overflow-y-auto"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/90 backdrop-blur-md"
        onClick={onClose}
      />

      <div className="relative min-h-full flex items-start justify-center px-4 py-8 sm:items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ type: "spring", damping: 26, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-xl glass-strong rounded-3xl overflow-hidden"
        >
          {/* Close */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>

          <div className="p-5 md:p-7">
            {/* Header */}
            <div className="flex items-center gap-4 mb-6">
              <AppIcon
                icon={project.icon}
                color={project.color}
                name={project.name}
              />
              <div>
                <h2 className="text-xl font-bold text-white">{project.name}</h2>
                <p className="text-white/50 text-xs">Mobile App</p>
              </div>
            </div>

            {/* Screenshots — big and clear */}
            <div className="mb-6">
              <ScreenshotGallery
                screenshots={project.screenshots}
                color={project.color}
                name={project.name}
              />
            </div>

            {/* Description */}
            <p className="text-white/70 mb-5 leading-relaxed text-sm md:text-base">
              {project.longDescription}
            </p>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-6">
              {project.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 text-xs rounded-full"
                  style={{
                    backgroundColor: `${project.color}20`,
                    color: project.color,
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Downloads */}
            <div className="flex flex-col sm:flex-row gap-3 mb-5">
              <DownloadButton
                type="apk"
                download={project.downloads.apk}
                color={project.color}
              />
              <DownloadButton
                type="ios"
                download={project.downloads.ios}
                color={project.color}
              />
            </div>

            {/* Links */}
            <div className="flex gap-4">
              {project.links?.github && (
                <a
                  href={project.links.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-white/50 hover:text-white transition-colors"
                >
                  <Github className="w-4 h-4" />
                  <span>Source</span>
                </a>
              )}
              {project.links?.live && (
                <a
                  href={project.links.live}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-white/50 hover:text-white transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Live</span>
                </a>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}

// ── Projects grid ─────────────────────────────────────────────────────────────
export function ProjectsScreen() {
  const [selected, setSelected] = useState<Project | null>(null);

  return (
    <div className="min-h-screen px-4 md:px-6 pt-8 md:pt-12 pb-24 overflow-y-auto hide-scrollbar">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 md:mb-10"
        >
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-2 md:mb-4">
            Projects
          </h1>
          <p className="text-sm md:text-lg text-white/50 max-w-2xl">
            A selection of mobile apps and tools I&apos;ve built spanning faith,
            health, productivity, and learning.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.07 }}
              whileHover={{ y: -5, scale: 1.015 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelected(project)}
              className="group cursor-pointer"
            >
              <div className="glass rounded-2xl md:rounded-3xl p-4 md:p-5 h-full transition-all">
                <div className="mb-4 flex justify-center transform group-hover:scale-105 transition-transform">
                  <AppIcon
                    icon={project.icon}
                    color={project.color}
                    name={project.name}
                  />
                </div>
                <h3 className="text-base md:text-lg font-semibold text-white mb-1.5 text-center">
                  {project.name}
                </h3>
                <p className="text-xs md:text-sm text-white/50 mb-3 line-clamp-2 text-center">
                  {project.description}
                </p>

                <div className="flex justify-center gap-3 mb-3">
                  <div
                    className={`flex items-center gap-1 text-xs ${project.downloads.apk.available ? "text-green-400" : "text-white/30"}`}
                  >
                    <Download className="w-3 h-3" />
                    <span>APK</span>
                  </div>
                  <div
                    className={`flex items-center gap-1 text-xs ${project.downloads.ios.available ? "text-green-400" : "text-white/30"}`}
                  >
                    <Apple className="w-3 h-3" />
                    <span>iOS</span>
                  </div>
                </div>

                <div className="flex flex-wrap justify-center gap-1.5">
                  {project.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 text-xs text-white/60 bg-white/5 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                  {project.tags.length > 3 && (
                    <span className="px-2 py-0.5 text-xs text-white/40 bg-white/5 rounded-full">
                      +{project.tags.length - 3}
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {selected && (
          <ProjectModal project={selected} onClose={() => setSelected(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}
