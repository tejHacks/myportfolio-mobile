"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Mail, Github, Linkedin, Twitter, ExternalLink, MapPin, Phone, FileText, MessageSquare, Check } from "lucide-react"

const socialLinks = [
  {
    name: "Email",
    icon: Mail,
    href: "mailto:olateju202@gmail.com",
    username: "olateju202@gmail.com",
    color: "#EA4335",
  },
  {
    name: "GitHub",
    icon: Github,
    href: "https://github.com/tejHacks",
    username: "@tejHacks",
    color: "#FFFFFF",
  },
  {
    name: "LinkedIn",
    icon: Linkedin,
    href: "https://www.linkedin.com/in/olateju-olamide-22314a292/",
    username: "Olateju Olamide",
    color: "#0A66C2",
  },
  {
    name: "X (Twitter)",
    icon: Twitter,
    href: "https://x.com/OlatejuOlamid10",
    username: "@OlatejuOlamid10",
    color: "#FFFFFF",
  },
  {
    name: "Medium",
    icon: MessageSquare,
    href: "https://medium.com/@olateju202/",
    username: "@olateju202",
    color: "#FFFFFF",
  },
]

export function ContactScreen() {
  const [copied, setCopied] = useState<string | null>(null)

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    setCopied(label)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <div className="min-h-screen px-4 md:px-6 pt-8 md:pt-12 pb-24 overflow-y-auto hide-scrollbar flex items-center justify-center">
      <div className="max-w-2xl mx-auto w-full">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 300, delay: 0.2 }}
            className="w-24 h-24 mx-auto mb-6 rounded-full glass flex items-center justify-center glow"
          >
            <Mail className="w-10 h-10 text-white" />
          </motion.div>

          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Get in Touch</h1>
          <p className="text-lg text-white/50 max-w-md mx-auto leading-relaxed text-pretty">
            {"Have a project in mind or just want to say hello? I'd love to hear from you."}
          </p>
        </motion.div>

        {/* Location & Phone */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="flex flex-col sm:flex-row flex-wrap items-center justify-center gap-4 mb-6 text-sm md:text-base"
        >
          <div className="flex items-center gap-2 text-white/60">
            <MapPin className="w-4 h-4" />
            <span>Ibadan, Nigeria</span>
          </div>
          <div className="flex items-center gap-2 text-white/60">
            <Phone className="w-4 h-4" />
            <span>+234 808 697 6247</span>
          </div>
        </motion.div>

        {/* Availability status */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="flex justify-center mb-8"
        >
          <div className="inline-flex items-center gap-3 glass rounded-full px-6 py-3">
            <motion.div
              animate={{
                opacity: [0.6, 1, 0.6],
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="w-2.5 h-2.5 rounded-full bg-green-400 will-change-opacity"
              style={{ backfaceVisibility: "hidden" }}
            />
            <span className="text-white/70">
              Available for freelance & full-time opportunities
            </span>
          </div>
        </motion.div>

        {/* Social links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="space-y-2 md:space-y-3"
        >
          {socialLinks.map((link, index) => {
            const Icon = link.icon
            const isCopied = copied === link.name

            return (
              <motion.div
                key={link.name}
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.08 }}
                className="flex gap-2"
              >
                <motion.a
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 group flex items-center gap-3 glass rounded-2xl p-3 md:p-4 glow-hover transition-all text-sm md:text-base"
                >
                  <div
                    className="w-10 h-10 md:w-11 md:h-11 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110 flex-shrink-0"
                    style={{ backgroundColor: `${link.color}20` }}
                  >
                    <Icon className="w-5 h-5" style={{ color: link.color }} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="text-white font-medium text-sm md:text-base">{link.name}</div>
                    <div className="text-xs md:text-sm text-white/50 truncate">{link.username}</div>
                  </div>

                  <ExternalLink className="w-4 h-4 md:w-5 md:h-5 text-white/30 group-hover:text-white transition-colors flex-shrink-0" />
                </motion.a>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => copyToClipboard(link.username, link.name)}
                  className={`p-3 md:p-4 rounded-2xl transition-all ${isCopied
                      ? "bg-green-500/20 text-green-400"
                      : "glass text-white/50 hover:text-white"
                    }`}
                  title={`Copy ${link.name}`}
                >
                  {isCopied ? (
                    <Check className="w-4 h-4 md:w-5 md:h-5" />
                  ) : (
                    <Mail className="w-4 h-4 md:w-5 md:h-5" />
                  )}
                </motion.button>
              </motion.div>
            )
          })}
        </motion.div>

        {/* Resume Download */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-8 flex justify-center"
        >
          <a
            href="/resume.pdf"
            download="Olateju_Olamide_Resume.pdf"
            className="group flex items-center gap-3 glass rounded-2xl px-6 py-4 glow-hover transition-all hover:bg-white/10"
          >
            <FileText className="w-5 h-5 text-white/70 group-hover:text-white transition-colors" />
            <span className="text-white font-medium">Download Resume</span>
            <span className="text-white/40 text-sm">(PDF)</span>
          </a>
        </motion.div>

        {/* Footer note */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="mt-12 text-center"
        >
          <p className="text-sm text-white/30">
            Response time: Usually within 24 hours
          </p>
        </motion.div>
      </div>
    </div>
  )
}
