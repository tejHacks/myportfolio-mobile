"use client"

import { useState, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Wifi, Signal, Zap } from "lucide-react"

interface BatteryManager extends EventTarget {
  charging: boolean
  chargingTime: number
  dischargingTime: number
  level: number
  onchargingchange: ((this: BatteryManager, ev: Event) => void) | null
  onchargingtimechange: ((this: BatteryManager, ev: Event) => void) | null
  ondischargingtimechange: ((this: BatteryManager, ev: Event) => void) | null
  onlevelchange: ((this: BatteryManager, ev: Event) => void) | null
}

declare global {
  interface Navigator {
    getBattery?: () => Promise<BatteryManager>
  }
}

interface BatteryState {
  level: number
  charging: boolean
}

function BatteryIcon({ level, charging }: BatteryState) {
  const fillWidth = Math.max(0, Math.min(100, level))
  
  // Determine battery color based on level and charging state
  const getBatteryColor = () => {
    if (charging) return "bg-green-400"
    if (level <= 10) return "bg-red-500"
    if (level <= 20) return "bg-orange-400"
    return "bg-white/80"
  }

  return (
    <div className="relative flex items-center gap-1">
      {/* Charging indicator */}
      <AnimatePresence>
        {charging && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            className="text-green-400"
          >
            <Zap className="w-3 h-3 fill-green-400" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Battery body */}
      <div className="relative w-6 h-3 border border-white/60 rounded-sm overflow-hidden">
        {/* Battery fill */}
        <motion.div
          className={`absolute left-0 top-0 bottom-0 ${getBatteryColor()}`}
          initial={{ width: 0 }}
          animate={{ width: `${fillWidth}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
        
        {/* Charging animation overlay */}
        {charging && (
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
            animate={{ x: ["-100%", "200%"] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          />
        )}
      </div>
      
      {/* Battery cap */}
      <div className="w-0.5 h-1.5 bg-white/60 rounded-r-sm -ml-0.5" />
    </div>
  )
}

export function StatusBar() {
  const [time, setTime] = useState<string>("")
  const [battery, setBattery] = useState<BatteryState | null>(null)
  const [mounted, setMounted] = useState(false)

  const updateBattery = useCallback((batteryManager: BatteryManager) => {
    setBattery({
      level: Math.round(batteryManager.level * 100),
      charging: batteryManager.charging,
    })
  }, [])

  useEffect(() => {
    setMounted(true)

    // Update time every second
    const updateTime = () => {
      const now = new Date()
      setTime(
        now.toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        })
      )
    }
    updateTime()
    const timeInterval = setInterval(updateTime, 1000)

    // Battery API
    let batteryManager: BatteryManager | null = null
    
    const initBattery = async () => {
      if (typeof navigator !== "undefined" && navigator.getBattery) {
        try {
          batteryManager = await navigator.getBattery()
          
          updateBattery(batteryManager)

          const handleChange = () => {
            if (batteryManager) {
              updateBattery(batteryManager)
            }
          }

          batteryManager.addEventListener("levelchange", handleChange)
          batteryManager.addEventListener("chargingchange", handleChange)
        } catch {
          // Battery API not supported, show fallback
          setBattery({ level: 100, charging: false })
        }
      } else {
        // Fallback for browsers without Battery API
        setBattery({ level: 100, charging: false })
      }
    }

    initBattery()

    return () => {
      clearInterval(timeInterval)
      if (batteryManager) {
        batteryManager.removeEventListener("levelchange", () => {})
        batteryManager.removeEventListener("chargingchange", () => {})
      }
    }
  }, [updateBattery])

  if (!mounted) {
    return (
      <div className="fixed top-0 left-0 right-0 z-50 h-7 glass">
        <div className="h-full" />
      </div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 h-7 glass"
    >
      <div className="h-full max-w-screen-xl mx-auto px-4 flex items-center justify-between">
        {/* Left side - Time */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-white/90">{time}</span>
        </div>

        {/* Right side - Status icons */}
        <div className="flex items-center gap-3">
          <Signal className="w-3.5 h-3.5 text-white/70" />
          <Wifi className="w-3.5 h-3.5 text-white/70" />

          {battery && (
            <div className="flex items-center gap-1.5">
              <BatteryIcon level={battery.level} charging={battery.charging} />
              <div className="flex items-center gap-0.5">
                <span className="text-xs text-white/70 tabular-nums">{battery.level}%</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  )
}
