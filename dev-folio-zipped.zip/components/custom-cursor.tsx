"use client"

import { useState, useEffect, useCallback } from "react"
import { motion, useSpring, useMotionValue } from "framer-motion"

export function CustomCursor() {
  const [isVisible, setIsVisible] = useState(false)
  const [isPointer, setIsPointer] = useState(false)
  const [isClicking, setIsClicking] = useState(false)
  const [isTouchDevice, setIsTouchDevice] = useState(true)

  const cursorX = useMotionValue(0)
  const cursorY = useMotionValue(0)

  const springConfig = { damping: 25, stiffness: 400, mass: 0.5 }
  const cursorXSpring = useSpring(cursorX, springConfig)
  const cursorYSpring = useSpring(cursorY, springConfig)

  const trailConfig = { damping: 20, stiffness: 200, mass: 0.8 }
  const trailXSpring = useSpring(cursorX, trailConfig)
  const trailYSpring = useSpring(cursorY, trailConfig)

  const updatePosition = useCallback((e: MouseEvent) => {
    cursorX.set(e.clientX)
    cursorY.set(e.clientY)

    const target = e.target as HTMLElement
    const isClickable =
      target.tagName === "BUTTON" ||
      target.tagName === "A" ||
      target.closest("button") !== null ||
      target.closest("a") !== null ||
      target.closest("[role='button']") !== null ||
      window.getComputedStyle(target).cursor === "pointer"
    setIsPointer(isClickable)
  }, [cursorX, cursorY])

  useEffect(() => {
    // Check if touch device
    const checkTouchDevice = () => {
      const hasCoarsePointer = window.matchMedia("(pointer: coarse)").matches
      const hasTouchPoints = navigator.maxTouchPoints > 0
      return hasCoarsePointer || hasTouchPoints
    }

    const isTouch = checkTouchDevice()
    setIsTouchDevice(isTouch)

    if (isTouch) return

    const handleMouseEnter = () => setIsVisible(true)
    const handleMouseLeave = () => setIsVisible(false)
    const handleMouseDown = () => setIsClicking(true)
    const handleMouseUp = () => setIsClicking(false)

    document.addEventListener("mousemove", updatePosition)
    document.addEventListener("mouseenter", handleMouseEnter)
    document.addEventListener("mouseleave", handleMouseLeave)
    document.addEventListener("mousedown", handleMouseDown)
    document.addEventListener("mouseup", handleMouseUp)

    // Add styles to hide default cursor
    const style = document.createElement("style")
    style.id = "custom-cursor-styles"
    style.textContent = `
      *, *::before, *::after {
        cursor: none !important;
      }
    `
    document.head.appendChild(style)

    setIsVisible(true)

    return () => {
      document.removeEventListener("mousemove", updatePosition)
      document.removeEventListener("mouseenter", handleMouseEnter)
      document.removeEventListener("mouseleave", handleMouseLeave)
      document.removeEventListener("mousedown", handleMouseDown)
      document.removeEventListener("mouseup", handleMouseUp)
      
      const existingStyle = document.getElementById("custom-cursor-styles")
      if (existingStyle) {
        existingStyle.remove()
      }
    }
  }, [updatePosition])

  if (isTouchDevice || !isVisible) return null

  return (
    <>
      {/* Main cursor dot */}
      <motion.div
        className="fixed top-0 left-0 pointer-events-none z-[9999]"
        style={{
          x: cursorXSpring,
          y: cursorYSpring,
          translateX: "-50%",
          translateY: "-50%",
        }}
      >
        <motion.div
          animate={{
            scale: isClicking ? 0.8 : isPointer ? 1.5 : 1,
            opacity: isClicking ? 0.8 : 1,
          }}
          transition={{ duration: 0.15 }}
          className="relative"
        >
          <div
            className={`w-4 h-4 rounded-full transition-colors duration-150 ${
              isPointer ? "bg-white" : "bg-white/90"
            }`}
            style={{
              boxShadow: isPointer
                ? "0 0 20px rgba(255, 255, 255, 0.6), 0 0 40px rgba(255, 255, 255, 0.3)"
                : "0 0 15px rgba(255, 255, 255, 0.4)",
            }}
          />
        </motion.div>
      </motion.div>

      {/* Trailing ring */}
      <motion.div
        className="fixed top-0 left-0 pointer-events-none z-[9998]"
        style={{
          x: trailXSpring,
          y: trailYSpring,
          translateX: "-50%",
          translateY: "-50%",
        }}
      >
        <motion.div
          animate={{
            scale: isPointer ? 1.8 : 1,
            opacity: isPointer ? 0.6 : 0.3,
          }}
          transition={{ duration: 0.2 }}
          className="w-8 h-8 rounded-full border border-white/40"
          style={{
            boxShadow: "0 0 10px rgba(255, 255, 255, 0.1)",
          }}
        />
      </motion.div>
    </>
  )
}
