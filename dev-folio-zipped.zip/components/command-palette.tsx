"use client"

import { useState, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Home,
  User,
  Layers,
  Briefcase,
  FolderKanban,
  BookOpen,
  Mail,
  Search,
  Command,
} from "lucide-react"

interface CommandPaletteProps {
  onNavigate: (screen: string) => void
}

const commands = [
  { id: "home", icon: Home, label: "Home", shortcut: "H" },
  { id: "about", icon: User, label: "About Me", shortcut: "A" },
  { id: "skills", icon: Layers, label: "Skills", shortcut: "S" },
  { id: "experience", icon: Briefcase, label: "Experience", shortcut: "E" },
  { id: "projects", icon: FolderKanban, label: "Projects", shortcut: "P" },
  { id: "writing", icon: BookOpen, label: "Writing", shortcut: "W" },
  { id: "contact", icon: Mail, label: "Contact", shortcut: "C" },
]

export function CommandPalette({ onNavigate }: CommandPaletteProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [search, setSearch] = useState("")
  const [selectedIndex, setSelectedIndex] = useState(0)

  const filteredCommands = commands.filter((cmd) =>
    cmd.label.toLowerCase().includes(search.toLowerCase())
  )

  const handleSelect = useCallback(
    (id: string) => {
      onNavigate(id)
      setIsOpen(false)
      setSearch("")
      setSelectedIndex(0)
    },
    [onNavigate]
  )

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Open command palette with Cmd+K or Ctrl+K
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault()
        setIsOpen((prev) => !prev)
      }

      // Close with Escape
      if (e.key === "Escape") {
        setIsOpen(false)
        setSearch("")
        setSelectedIndex(0)
      }

      // Navigate with arrows when open
      if (isOpen) {
        if (e.key === "ArrowDown") {
          e.preventDefault()
          setSelectedIndex((prev) =>
            prev < filteredCommands.length - 1 ? prev + 1 : 0
          )
        }
        if (e.key === "ArrowUp") {
          e.preventDefault()
          setSelectedIndex((prev) =>
            prev > 0 ? prev - 1 : filteredCommands.length - 1
          )
        }
        if (e.key === "Enter" && filteredCommands[selectedIndex]) {
          handleSelect(filteredCommands[selectedIndex].id)
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isOpen, filteredCommands, selectedIndex, handleSelect])

  // Reset selected index when search changes
  useEffect(() => {
    setSelectedIndex(0)
  }, [search])

  return (
    <>
      {/* Keyboard shortcut hint */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        onClick={() => setIsOpen(true)}
        className="fixed top-10 right-4 z-40 glass rounded-lg px-3 py-1.5 flex items-center gap-2 text-xs text-white/60 hover:text-white/90 transition-colors"
      >
        <Command className="w-3 h-3" />
        <span>K</span>
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm"
            />

            {/* Command palette */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
              className="fixed top-[20%] left-1/2 -translate-x-1/2 z-[101] w-full max-w-lg"
            >
              <div className="glass-strong rounded-2xl overflow-hidden shadow-2xl">
                {/* Search input */}
                <div className="flex items-center gap-3 px-4 py-4 border-b border-white/10">
                  <Search className="w-5 h-5 text-white/50" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search or jump to..."
                    className="flex-1 bg-transparent text-white placeholder-white/40 outline-none"
                    autoFocus
                  />
                  <kbd className="px-2 py-1 text-xs text-white/40 bg-white/5 rounded">
                    ESC
                  </kbd>
                </div>

                {/* Commands list */}
                <div className="max-h-80 overflow-y-auto py-2">
                  {filteredCommands.length === 0 ? (
                    <div className="px-4 py-8 text-center text-white/40">
                      No results found
                    </div>
                  ) : (
                    filteredCommands.map((cmd, index) => {
                      const Icon = cmd.icon
                      const isSelected = index === selectedIndex
                      return (
                        <button
                          key={cmd.id}
                          onClick={() => handleSelect(cmd.id)}
                          onMouseEnter={() => setSelectedIndex(index)}
                          className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors ${
                            isSelected
                              ? "bg-white/10 text-white"
                              : "text-white/70 hover:bg-white/5"
                          }`}
                        >
                          <Icon className="w-5 h-5" />
                          <span className="flex-1">{cmd.label}</span>
                          <kbd className="px-2 py-0.5 text-xs text-white/40 bg-white/5 rounded">
                            {cmd.shortcut}
                          </kbd>
                        </button>
                      )
                    })
                  )}
                </div>

                {/* Footer hint */}
                <div className="px-4 py-3 border-t border-white/10 flex items-center gap-4 text-xs text-white/40">
                  <span className="flex items-center gap-1">
                    <kbd className="px-1.5 py-0.5 bg-white/5 rounded">↑</kbd>
                    <kbd className="px-1.5 py-0.5 bg-white/5 rounded">↓</kbd>
                    to navigate
                  </span>
                  <span className="flex items-center gap-1">
                    <kbd className="px-1.5 py-0.5 bg-white/5 rounded">↵</kbd>
                    to select
                  </span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
